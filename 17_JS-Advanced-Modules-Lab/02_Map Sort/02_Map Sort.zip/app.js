//Require/Import mapSort
let mapSort = require('./mapSort');

result.mapSort = mapSort;