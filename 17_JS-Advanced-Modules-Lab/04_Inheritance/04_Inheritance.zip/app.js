//Require/Import each class
import Entity from "./entity.js";
import Person from "./person.js";
import Dog from "./dog.js";
import Student from "./student.js";

result.Entity = Entity;
result.Person = Person;
result.Dog = Dog;
result.Student = Student;

// let student1 = new Student('Pesho', 'what up', new Dog('Rex'), '1234');
// console.log(student1.saySomething());
